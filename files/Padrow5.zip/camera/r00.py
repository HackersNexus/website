import telebot 
def send_url(message, id, token) :
 bot = telebot.TeleBot(token)
 print(id)
 print(token)
 bot.send_message(id, message)

def send_file(file, id, token) :
 print("send image")
 print(id)
 print(token)
 print(file)
 bot = telebot.TeleBot(token)
 with open(file, "rb") as file :
   bot.send_document(id, file)
 